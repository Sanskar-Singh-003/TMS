import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import CourseList from './components/CourseList';
import CourseDetails from './components/CourseDetails';
import MyEnrollments from './components/MyEnrollments';
import AddCourse from './components/AddCourse';

function App() {
    return (
        <Router>
            <nav>
                <link to="/">Course List</link> |{''}
                <link to="/add-course">Add Course</link>
            </nav>

            <Routes>
                <Route path="/" element={<CourseList />} />
                <Route path="/course/:id" element={<CourseDetails />} />
                <Route path="/add-course" element={<AddCourse />} />
                <Route path="/learners/:id/enrollments" element={<MyEnrollments />} />
            </Routes>
        </Router>
    );
}

export default App;