import axios from 'axios';

// IMPORTANT: REPLACE 7061 WITH YOUR SWAGGER PORT FROM PHASE 1 STEP 5
const API_BASE_URL = 'https://localhost:7248/api';

export const getCourses = () => axios.get(API_BASE_URL);
export const getCourseById = (id) => axios.get(`${API_BASE_URL}/courses/${id}`);
export const addCourse = (course) => axios.post(`${API_BASE_URL}/courses`, course);
export const addLearner = (learner) => axios.post(`${API_BASE_URL}/learners`, learner);
export const addEnrollment = (enrollment) => axios.post(`${API_BASE_URL}/enrollments`, enrollment);
export const getLearnerEnrollments = (learnerId) => axios.get(`${API_BASE_URL}/learners/${learnerId}/enrollments`);
export const getCourseEnrollments = (courseId) => axios.get(`${API_BASE_URL}/courses/${courseId}/enrollments`);