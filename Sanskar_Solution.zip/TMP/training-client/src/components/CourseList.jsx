function CourseList() {
    return (
        <p>Hello world!</p>
    );
}

export default CourseList;