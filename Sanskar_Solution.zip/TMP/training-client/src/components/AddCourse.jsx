function AddCourse() {
  return (
    <p>Hello world!</p>
  );
}

export default AddCourse;