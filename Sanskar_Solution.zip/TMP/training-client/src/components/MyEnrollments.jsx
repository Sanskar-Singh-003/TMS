function MyEnrollments() {
    return (
        <p>Hello world!</p>
    );
}

export default MyEnrollments;