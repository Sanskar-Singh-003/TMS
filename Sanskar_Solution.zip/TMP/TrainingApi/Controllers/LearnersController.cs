using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TrainingApi.Models;
using TrainingApi.Data;

[Route("api/[controller]")]
[ApiController]
public class LearnersController : ControllerBase
{
    private readonly TrainingApiDbContext _context;
    public LearnersController(TrainingApiDbContext context)
    {
        _context = context;
    }

    // GET: api/Learner
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Learner>>> GetLearner()
    {
        return await _context.Learners.ToListAsync();
    }

    // GET: api/Learner/5
    [HttpGet("{id}")]
    public async Task<ActionResult<Learner>> GetLearner(int id)
    {
        var learner = await _context.Learners.FindAsync(id);

        if (learner == null)
        {
            return NotFound();
        }

        return learner;
    }

    // PUT: api/Learner/5
    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
    [HttpPut("{id}")]
    public async Task<IActionResult> PutLearner(int? id, Learner learner)
    {
        if (id != learner.Id)
        {
            return BadRequest();
        }

        _context.Entry(learner).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!LearnerExists(id))
            {
                return NotFound();
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }

    // POST: api/Learner
    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
    [HttpPost]
    public async Task<ActionResult<Learner>> PostLearner(Learner learner)
    {
        _context.Learners.Add(learner);
        await _context.SaveChangesAsync();

        return CreatedAtAction("GetLearner", new { id = learner.Id }, learner);
    }

    // DELETE: api/Learner/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteLearner(int? id)
    {
        var learner = await _context.Learners.FindAsync(id);
        if (learner == null)
        {
            return NotFound();
        }

        _context.Learners.Remove(learner);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private bool LearnerExists(int? id)
    {
        return _context.Learners.Any(e => e.Id == id);
    }
}
