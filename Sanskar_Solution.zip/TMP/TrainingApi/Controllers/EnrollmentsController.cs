using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TrainingApi.Models;
using TrainingApi.Data;

[Route("api/[controller]")]
[ApiController]
public class EnrollmentsController : ControllerBase
{
    private readonly TrainingApiDbContext _context;
    public EnrollmentsController(TrainingApiDbContext context)
    {
        _context = context;
    }

    // GET: api/Enrollment
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Enrollment>>> GetEnrollment()
    {
        return await _context.Enrollments.ToListAsync();
    }

    // GET: api/Enrollment/5
    [HttpGet("{id}")]
    public async Task<ActionResult<Enrollment>> GetEnrollment(int id)
    {
        var enrollment = await _context.Enrollments.FindAsync(id);

        if (enrollment == null)
        {
            return NotFound();
        }

        return enrollment;
    }

    // PUT: api/Enrollment/5
    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
    [HttpPut("{id}")]
    public async Task<IActionResult> PutEnrollment(int? id, Enrollment enrollment)
    {
        if (id != enrollment.Id)
        {
            return BadRequest();
        }

        _context.Entry(enrollment).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!EnrollmentExists(id))
            {
                return NotFound();
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }

    // POST: api/Enrollment
    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
    [HttpPost]
    public async Task<ActionResult<Enrollment>> PostEnrollment(Enrollment enrollment)
    {
        _context.Enrollments.Add(enrollment);
        await _context.SaveChangesAsync();

        return CreatedAtAction("GetEnrollment", new { id = enrollment.Id }, enrollment);
    }

    // DELETE: api/Enrollment/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteEnrollment(int? id)
    {
        var enrollment = await _context.Enrollments.FindAsync(id);
        if (enrollment == null)
        {
            return NotFound();
        }

        _context.Enrollments.Remove(enrollment);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private bool EnrollmentExists(int? id)
    {
        return _context.Enrollments.Any(e => e.Id == id);
    }
}
