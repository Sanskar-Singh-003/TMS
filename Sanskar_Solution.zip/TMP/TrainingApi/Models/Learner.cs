﻿using System.ComponentModel.DataAnnotations;

namespace TrainingApi.Models
{
    public class Learner
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [Key]
        public string Email { get; set; } = string.Empty;

        public ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();



    }
}
