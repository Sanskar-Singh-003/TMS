﻿using System.ComponentModel.DataAnnotations;

namespace TrainingApi.Models
{
    public class Enrollment
    {
        public int Id { get; set; }

        [Required]
        public int CourseId { get; set; }
        [Required]
        public int LearnerId { get; set; }

        public DateTime EnrollmentDate { get; set; } = DateTime.Now;

        [Required]
        public EnrollmentStatus Status { get; set; } = EnrollmentStatus.Confirmed;

        public Course? Course { get; set; } = null!;
        public Learner? Learner { get; set; } = null!;
    }

    public enum EnrollmentStatus
    {
        Confirmed,
        Completed,
        Cancelled,
        InProgress

    }
}
