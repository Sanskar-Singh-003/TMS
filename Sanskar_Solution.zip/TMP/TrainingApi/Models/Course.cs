﻿using System.ComponentModel.DataAnnotations;

namespace TrainingApi.Models
{
    public class Course
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Title { get; set; } = string.Empty;

        [MaxLength(250)]
        public string Description { get; set; }

        public CourseCategory Category { get; set; }

        public int Duration { get; set; }

        [Required]
        public Courselevel Level { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
        
        public ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
    }

    public enum Courselevel
    {
        Beginner,
        Intermediate,
        Advanced
    }

    public enum  CourseCategory
    {
        Beginner,
        Intermediate,
        Advanced

    }
}
