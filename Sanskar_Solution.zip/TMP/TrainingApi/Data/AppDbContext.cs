﻿using TrainingApi.Models;
using Microsoft.EntityFrameworkCore;

namespace TrainingApi.Data
{
    public class TrainingApiDbContext            : DbContext
    {
        public TrainingApiDbContext(DbContextOptions<TrainingApiDbContext> options) : base(options) { }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Learner> Learners { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
    }
}